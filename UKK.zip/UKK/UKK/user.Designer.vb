﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class user
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(user))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2p = New System.Windows.Forms.Label()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label8p = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox1p = New System.Windows.Forms.GroupBox()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.GroupBox2p = New System.Windows.Forms.GroupBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.GroupBox3p = New System.Windows.Forms.GroupBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.Label13p = New System.Windows.Forms.Label()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label7p = New System.Windows.Forms.Label()
        Me.Label6p = New System.Windows.Forms.Label()
        Me.Label5p = New System.Windows.Forms.Label()
        Me.GroupBox3pp = New System.Windows.Forms.GroupBox()
        Me.Button6 = New System.Windows.Forms.Button()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.GroupBox5p = New System.Windows.Forms.GroupBox()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.Label3p = New System.Windows.Forms.Label()
        Me.Label4p = New System.Windows.Forms.Label()
        Me.DGV = New System.Windows.Forms.DataGridView()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.GroupBox1p.SuspendLayout()
        Me.GroupBox2p.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3p.SuspendLayout()
        Me.GroupBox3pp.SuspendLayout()
        Me.GroupBox5p.SuspendLayout()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 26.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1178, 64)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Form User"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'Label2p
        '
        Me.Label2p.BackColor = System.Drawing.Color.Black
        Me.Label2p.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label2p.Location = New System.Drawing.Point(0, 64)
        Me.Label2p.Name = "Label2p"
        Me.Label2p.Size = New System.Drawing.Size(1178, 23)
        Me.Label2p.TabIndex = 2
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.ForeColor = System.Drawing.Color.Yellow
        Me.Button1.Location = New System.Drawing.Point(26, 532)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(181, 37)
        Me.Button1.TabIndex = 19
        Me.Button1.Text = "Keluar"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Label8.Font = New System.Drawing.Font("Trebuchet MS", 14.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.Control
        Me.Label8.Location = New System.Drawing.Point(34, 478)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(161, 42)
        Me.Label8.TabIndex = 17
        Me.Label8.Text = "Register"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8p
        '
        Me.Label8p.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Label8p.Location = New System.Drawing.Point(0, 87)
        Me.Label8p.Name = "Label8p"
        Me.Label8p.Size = New System.Drawing.Size(247, 530)
        Me.Label8p.TabIndex = 20
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Label7.Font = New System.Drawing.Font("Trebuchet MS", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.ForeColor = System.Drawing.SystemColors.Control
        Me.Label7.Location = New System.Drawing.Point(4, 96)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(224, 55)
        Me.Label7.TabIndex = 21
        Me.Label7.Text = "Administrator"
        '
        'GroupBox1p
        '
        Me.GroupBox1p.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox1p.Controls.Add(Me.ComboBox1)
        Me.GroupBox1p.Controls.Add(Me.Button2)
        Me.GroupBox1p.Controls.Add(Me.GroupBox2p)
        Me.GroupBox1p.Controls.Add(Me.GroupBox3p)
        Me.GroupBox1p.Controls.Add(Me.Label13p)
        Me.GroupBox1p.Controls.Add(Me.TextBox2)
        Me.GroupBox1p.Controls.Add(Me.TextBox1)
        Me.GroupBox1p.Controls.Add(Me.Label7p)
        Me.GroupBox1p.Controls.Add(Me.Label6p)
        Me.GroupBox1p.Controls.Add(Me.Label5p)
        Me.GroupBox1p.Location = New System.Drawing.Point(245, 87)
        Me.GroupBox1p.Name = "GroupBox1p"
        Me.GroupBox1p.Size = New System.Drawing.Size(921, 352)
        Me.GroupBox1p.TabIndex = 22
        Me.GroupBox1p.TabStop = False
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Location = New System.Drawing.Point(200, 97)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(503, 28)
        Me.ComboBox1.TabIndex = 18
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(200, 315)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(703, 31)
        Me.Button2.TabIndex = 17
        Me.Button2.Text = "Cari Foto"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'GroupBox2p
        '
        Me.GroupBox2p.Controls.Add(Me.PictureBox1)
        Me.GroupBox2p.Location = New System.Drawing.Point(709, 19)
        Me.GroupBox2p.Name = "GroupBox2p"
        Me.GroupBox2p.Size = New System.Drawing.Size(200, 199)
        Me.GroupBox2p.TabIndex = 15
        Me.GroupBox2p.TabStop = False
        Me.GroupBox2p.Text = "Foto"
        '
        'PictureBox1
        '
        Me.PictureBox1.Location = New System.Drawing.Point(1, 25)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(199, 174)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 15
        Me.PictureBox1.TabStop = False
        '
        'GroupBox3p
        '
        Me.GroupBox3p.Controls.Add(Me.TextBox5)
        Me.GroupBox3p.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.GroupBox3p.Location = New System.Drawing.Point(200, 231)
        Me.GroupBox3p.Name = "GroupBox3p"
        Me.GroupBox3p.Size = New System.Drawing.Size(715, 83)
        Me.GroupBox3p.TabIndex = 12
        Me.GroupBox3p.TabStop = False
        Me.GroupBox3p.Text = "Lokasi Folder"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(6, 25)
        Me.TextBox5.Multiline = True
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.ReadOnly = True
        Me.TextBox5.Size = New System.Drawing.Size(697, 52)
        Me.TextBox5.TabIndex = 13
        '
        'Label13p
        '
        Me.Label13p.AutoSize = True
        Me.Label13p.Location = New System.Drawing.Point(33, 238)
        Me.Label13p.Name = "Label13p"
        Me.Label13p.Size = New System.Drawing.Size(42, 20)
        Me.Label13p.TabIndex = 11
        Me.Label13p.Text = "Foto"
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(200, 64)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(445, 26)
        Me.TextBox2.TabIndex = 4
        Me.TextBox2.UseSystemPasswordChar = True
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(200, 26)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(503, 26)
        Me.TextBox1.TabIndex = 3
        '
        'Label7p
        '
        Me.Label7p.AutoSize = True
        Me.Label7p.Location = New System.Drawing.Point(33, 105)
        Me.Label7p.Name = "Label7p"
        Me.Label7p.Size = New System.Drawing.Size(94, 20)
        Me.Label7p.TabIndex = 2
        Me.Label7p.Text = "Status User"
        '
        'Label6p
        '
        Me.Label6p.AutoSize = True
        Me.Label6p.Location = New System.Drawing.Point(33, 64)
        Me.Label6p.Name = "Label6p"
        Me.Label6p.Size = New System.Drawing.Size(78, 20)
        Me.Label6p.TabIndex = 1
        Me.Label6p.Text = "Password"
        '
        'Label5p
        '
        Me.Label5p.AutoSize = True
        Me.Label5p.Location = New System.Drawing.Point(28, 26)
        Me.Label5p.Name = "Label5p"
        Me.Label5p.Size = New System.Drawing.Size(83, 20)
        Me.Label5p.TabIndex = 0
        Me.Label5p.Text = "Username"
        '
        'GroupBox3pp
        '
        Me.GroupBox3pp.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox3pp.Controls.Add(Me.Button6)
        Me.GroupBox3pp.Controls.Add(Me.Button5)
        Me.GroupBox3pp.Controls.Add(Me.Button4)
        Me.GroupBox3pp.Controls.Add(Me.Button3)
        Me.GroupBox3pp.Controls.Add(Me.TextBox7)
        Me.GroupBox3pp.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.GroupBox3pp.Location = New System.Drawing.Point(246, 445)
        Me.GroupBox3pp.Name = "GroupBox3pp"
        Me.GroupBox3pp.Size = New System.Drawing.Size(920, 112)
        Me.GroupBox3pp.TabIndex = 23
        Me.GroupBox3pp.TabStop = False
        Me.GroupBox3pp.Text = "Proses"
        '
        'Button6
        '
        Me.Button6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button6.Image = CType(resources.GetObject("Button6.Image"), System.Drawing.Image)
        Me.Button6.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button6.Location = New System.Drawing.Point(744, 23)
        Me.Button6.Name = "Button6"
        Me.Button6.Size = New System.Drawing.Size(110, 81)
        Me.Button6.TabIndex = 17
        Me.Button6.Text = "new"
        Me.Button6.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button6.UseVisualStyleBackColor = True
        '
        'Button5
        '
        Me.Button5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button5.Image = CType(resources.GetObject("Button5.Image"), System.Drawing.Image)
        Me.Button5.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button5.Location = New System.Drawing.Point(527, 23)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(105, 81)
        Me.Button5.TabIndex = 16
        Me.Button5.Text = "cancel"
        Me.Button5.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button4.Location = New System.Drawing.Point(273, 23)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(114, 81)
        Me.Button4.TabIndex = 15
        Me.Button4.Text = "delete"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button3.Location = New System.Drawing.Point(31, 25)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(110, 81)
        Me.Button3.TabIndex = 0
        Me.Button3.Text = "save"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button3.UseVisualStyleBackColor = True
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(11, 23)
        Me.TextBox7.Multiline = True
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(897, 83)
        Me.TextBox7.TabIndex = 14
        '
        'GroupBox5p
        '
        Me.GroupBox5p.BackColor = System.Drawing.SystemColors.Control
        Me.GroupBox5p.Controls.Add(Me.TextBox6)
        Me.GroupBox5p.ForeColor = System.Drawing.Color.LightSeaGreen
        Me.GroupBox5p.Location = New System.Drawing.Point(246, 563)
        Me.GroupBox5p.Name = "GroupBox5p"
        Me.GroupBox5p.Size = New System.Drawing.Size(702, 66)
        Me.GroupBox5p.TabIndex = 24
        Me.GroupBox5p.TabStop = False
        Me.GroupBox5p.Text = "Cari Data"
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(11, 24)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(650, 30)
        Me.TextBox6.TabIndex = 16
        '
        'Label3p
        '
        Me.Label3p.AutoSize = True
        Me.Label3p.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Label3p.Font = New System.Drawing.Font("Microsoft Sans Serif", 22.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3p.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label3p.Location = New System.Drawing.Point(971, 577)
        Me.Label3p.Name = "Label3p"
        Me.Label3p.Size = New System.Drawing.Size(146, 52)
        Me.Label3p.TabIndex = 25
        Me.Label3p.Text = "PPDB"
        '
        'Label4p
        '
        Me.Label4p.BackColor = System.Drawing.Color.LightSeaGreen
        Me.Label4p.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Label4p.Font = New System.Drawing.Font("Tahoma", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4p.ForeColor = System.Drawing.SystemColors.Control
        Me.Label4p.Location = New System.Drawing.Point(0, 914)
        Me.Label4p.Name = "Label4p"
        Me.Label4p.Size = New System.Drawing.Size(1178, 30)
        Me.Label4p.TabIndex = 26
        Me.Label4p.Text = "www.smktarunabangsa.sch.id"
        Me.Label4p.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        '
        'DGV
        '
        Me.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV.Location = New System.Drawing.Point(5, 635)
        Me.DGV.Name = "DGV"
        Me.DGV.RowTemplate.Height = 28
        Me.DGV.Size = New System.Drawing.Size(1162, 256)
        Me.DGV.TabIndex = 27
        '
        'PictureBox2
        '
        Me.PictureBox2.BackColor = System.Drawing.Color.LightSeaGreen
        Me.PictureBox2.Location = New System.Drawing.Point(18, 171)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(189, 217)
        Me.PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.PictureBox2.TabIndex = 18
        Me.PictureBox2.TabStop = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'user
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1178, 944)
        Me.Controls.Add(Me.DGV)
        Me.Controls.Add(Me.Label4p)
        Me.Controls.Add(Me.Label3p)
        Me.Controls.Add(Me.GroupBox5p)
        Me.Controls.Add(Me.GroupBox3pp)
        Me.Controls.Add(Me.GroupBox1p)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.Label8p)
        Me.Controls.Add(Me.Label2p)
        Me.Controls.Add(Me.Label1)
        Me.MaximumSize = New System.Drawing.Size(1200, 1000)
        Me.MinimumSize = New System.Drawing.Size(1200, 1000)
        Me.Name = "user"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "user"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1p.ResumeLayout(False)
        Me.GroupBox1p.PerformLayout()
        Me.GroupBox2p.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3p.ResumeLayout(False)
        Me.GroupBox3p.PerformLayout()
        Me.GroupBox3pp.ResumeLayout(False)
        Me.GroupBox3pp.PerformLayout()
        Me.GroupBox5p.ResumeLayout(False)
        Me.GroupBox5p.PerformLayout()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2p As System.Windows.Forms.Label
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents Label8p As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1p As System.Windows.Forms.GroupBox
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents GroupBox2p As System.Windows.Forms.GroupBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox3p As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents Label13p As System.Windows.Forms.Label
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label7p As System.Windows.Forms.Label
    Friend WithEvents Label6p As System.Windows.Forms.Label
    Friend WithEvents Label5p As System.Windows.Forms.Label
    Friend WithEvents GroupBox3pp As System.Windows.Forms.GroupBox
    Friend WithEvents Button6 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox5p As System.Windows.Forms.GroupBox
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents Label3p As System.Windows.Forms.Label
    Friend WithEvents Label4p As System.Windows.Forms.Label
    Friend WithEvents DGV As System.Windows.Forms.DataGridView
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
End Class
