﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Menu_Utama
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Menu_Utama))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ApplicationToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.UtilityToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Label5 = New System.Windows.Forms.Label()
        Me.panel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.panel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.panel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.Button13 = New System.Windows.Forms.Button()
        Me.Button12 = New System.Windows.Forms.Button()
        Me.Button11 = New System.Windows.Forms.Button()
        Me.Button10 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.FormBarcodeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormQRCodeToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormFungsiLeftMidRightToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormInputNilaiSiswaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormMediaPlayerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormKalkulatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormLuasSegitigaToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormLuasKelilingPersegipToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.FormLoopingToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangePasswordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackupDatabaseToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ChangeBackgroundToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CloseProgramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox8.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label1.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label1.Location = New System.Drawing.Point(0, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(1924, 39)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "- DASHBOARD PPDB (PENERIMAAN PESERTA DIDIK BARU) -"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Black
        Me.Label2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label2.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label2.Location = New System.Drawing.Point(0, 39)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(1924, 34)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "SMK TARUNA BANGSA - KOTA BEKASI"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ApplicationToolStripMenuItem, Me.UtilityToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 73)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1924, 32)
        Me.MenuStrip1.TabIndex = 6
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ApplicationToolStripMenuItem
        '
        Me.ApplicationToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FormBarcodeToolStripMenuItem, Me.FormQRCodeToolStripMenuItem, Me.FormFungsiLeftMidRightToolStripMenuItem, Me.FormInputNilaiSiswaToolStripMenuItem, Me.FormMediaPlayerToolStripMenuItem, Me.FormKalkulatorToolStripMenuItem, Me.FormLuasSegitigaToolStripMenuItem, Me.FormLuasKelilingPersegipToolStripMenuItem, Me.FormLoopingToolStripMenuItem})
        Me.ApplicationToolStripMenuItem.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ApplicationToolStripMenuItem.Name = "ApplicationToolStripMenuItem"
        Me.ApplicationToolStripMenuItem.Size = New System.Drawing.Size(120, 28)
        Me.ApplicationToolStripMenuItem.Text = "Application"
        '
        'UtilityToolStripMenuItem
        '
        Me.UtilityToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ChangePasswordToolStripMenuItem, Me.BackupDatabaseToolStripMenuItem, Me.ChangeBackgroundToolStripMenuItem})
        Me.UtilityToolStripMenuItem.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UtilityToolStripMenuItem.Name = "UtilityToolStripMenuItem"
        Me.UtilityToolStripMenuItem.Size = New System.Drawing.Size(74, 28)
        Me.UtilityToolStripMenuItem.Text = "Utility"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(55, 28)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(1569, 73)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(49, 20)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "Hello,"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.Button4)
        Me.GroupBox7.Controls.Add(Me.Button3)
        Me.GroupBox7.Controls.Add(Me.Button2)
        Me.GroupBox7.Controls.Add(Me.Button1)
        Me.GroupBox7.Location = New System.Drawing.Point(6, 19)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(500, 136)
        Me.GroupBox7.TabIndex = 0
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Aplikaciton"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.GroupBox7)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(4, 108)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(515, 161)
        Me.GroupBox2.TabIndex = 23
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Shortcut menu"
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.Button12)
        Me.GroupBox8.Controls.Add(Me.Button11)
        Me.GroupBox8.Controls.Add(Me.Button10)
        Me.GroupBox8.Location = New System.Drawing.Point(525, 118)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(383, 151)
        Me.GroupBox8.TabIndex = 24
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Utility"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button13)
        Me.GroupBox1.Location = New System.Drawing.Point(914, 128)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(139, 135)
        Me.GroupBox1.TabIndex = 25
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Exit"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.ForeColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label6.Location = New System.Drawing.Point(13, 28)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(190, 74)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "00.00"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Font = New System.Drawing.Font("Tahoma", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(1059, 141)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(210, 114)
        Me.GroupBox3.TabIndex = 26
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Time"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        Me.Timer1.Interval = 1000
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.Label5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Label5.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.ForeColor = System.Drawing.SystemColors.ButtonFace
        Me.Label5.Location = New System.Drawing.Point(0, 1010)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(1924, 40)
        Me.Label5.TabIndex = 28
        Me.Label5.Text = "www.smktarunabangsa.sch.id"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'panel1
        '
        Me.panel1.Name = "panel1"
        Me.panel1.Size = New System.Drawing.Size(180, 25)
        Me.panel1.Text = "ToolStripStatusLabel1"
        '
        'panel2
        '
        Me.panel2.Name = "panel2"
        Me.panel2.Size = New System.Drawing.Size(180, 25)
        Me.panel2.Text = "ToolStripStatusLabel2"
        '
        'panel3
        '
        Me.panel3.Name = "panel3"
        Me.panel3.Size = New System.Drawing.Size(180, 25)
        Me.panel3.Text = "ToolStripStatusLabel3"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 980)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(1924, 30)
        Me.StatusStrip1.TabIndex = 30
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(59, 25)
        Me.ToolStripStatusLabel1.Text = "Nama"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(180, 25)
        Me.ToolStripStatusLabel2.Text = "ToolStripStatusLabel2"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(180, 25)
        Me.ToolStripStatusLabel3.Text = "ToolStripStatusLabel3"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(1698, 73)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(40, 20)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "user"
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.UKK.My.Resources.Resources.BGTB
        Me.PictureBox3.Location = New System.Drawing.Point(4, 292)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(1924, 616)
        Me.PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage
        Me.PictureBox3.TabIndex = 29
        Me.PictureBox3.TabStop = False
        '
        'Button13
        '
        Me.Button13.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button13.Image = CType(resources.GetObject("Button13.Image"), System.Drawing.Image)
        Me.Button13.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button13.Location = New System.Drawing.Point(6, 28)
        Me.Button13.Name = "Button13"
        Me.Button13.Size = New System.Drawing.Size(123, 99)
        Me.Button13.TabIndex = 13
        Me.Button13.Text = "Close"
        Me.Button13.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button13.UseVisualStyleBackColor = True
        '
        'Button12
        '
        Me.Button12.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button12.Image = CType(resources.GetObject("Button12.Image"), System.Drawing.Image)
        Me.Button12.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button12.Location = New System.Drawing.Point(253, 36)
        Me.Button12.Name = "Button12"
        Me.Button12.Size = New System.Drawing.Size(122, 108)
        Me.Button12.TabIndex = 13
        Me.Button12.Text = "Change Background"
        Me.Button12.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button12.UseVisualStyleBackColor = True
        '
        'Button11
        '
        Me.Button11.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button11.Image = CType(resources.GetObject("Button11.Image"), System.Drawing.Image)
        Me.Button11.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button11.Location = New System.Drawing.Point(128, 38)
        Me.Button11.Name = "Button11"
        Me.Button11.Size = New System.Drawing.Size(119, 107)
        Me.Button11.TabIndex = 12
        Me.Button11.Text = "Backup Database"
        Me.Button11.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button11.UseVisualStyleBackColor = True
        '
        'Button10
        '
        Me.Button10.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button10.Image = CType(resources.GetObject("Button10.Image"), System.Drawing.Image)
        Me.Button10.ImageAlign = System.Drawing.ContentAlignment.TopCenter
        Me.Button10.Location = New System.Drawing.Point(6, 37)
        Me.Button10.Name = "Button10"
        Me.Button10.Size = New System.Drawing.Size(116, 107)
        Me.Button10.TabIndex = 11
        Me.Button10.Text = "Change Password"
        Me.Button10.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button10.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button4.Image = CType(resources.GetObject("Button4.Image"), System.Drawing.Image)
        Me.Button4.Location = New System.Drawing.Point(355, 28)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(136, 99)
        Me.Button4.TabIndex = 13
        Me.Button4.Text = "Hasil Tes"
        Me.Button4.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Image = CType(resources.GetObject("Button3.Image"), System.Drawing.Image)
        Me.Button3.Location = New System.Drawing.Point(250, 28)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(99, 99)
        Me.Button3.TabIndex = 12
        Me.Button3.Text = "Tes"
        Me.Button3.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Image = CType(resources.GetObject("Button2.Image"), System.Drawing.Image)
        Me.Button2.Location = New System.Drawing.Point(130, 28)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(114, 99)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "Siswa"
        Me.Button2.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Tahoma", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Image = CType(resources.GetObject("Button1.Image"), System.Drawing.Image)
        Me.Button1.Location = New System.Drawing.Point(6, 28)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(118, 99)
        Me.Button1.TabIndex = 10
        Me.Button1.Text = "User"
        Me.Button1.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.Button1.UseVisualStyleBackColor = True
        '
        'FormBarcodeToolStripMenuItem
        '
        Me.FormBarcodeToolStripMenuItem.Image = CType(resources.GetObject("FormBarcodeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FormBarcodeToolStripMenuItem.Name = "FormBarcodeToolStripMenuItem"
        Me.FormBarcodeToolStripMenuItem.Size = New System.Drawing.Size(337, 28)
        Me.FormBarcodeToolStripMenuItem.Text = "Form Barcode"
        '
        'FormQRCodeToolStripMenuItem
        '
        Me.FormQRCodeToolStripMenuItem.Image = CType(resources.GetObject("FormQRCodeToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FormQRCodeToolStripMenuItem.Name = "FormQRCodeToolStripMenuItem"
        Me.FormQRCodeToolStripMenuItem.Size = New System.Drawing.Size(337, 28)
        Me.FormQRCodeToolStripMenuItem.Text = "Form QR Code"
        '
        'FormFungsiLeftMidRightToolStripMenuItem
        '
        Me.FormFungsiLeftMidRightToolStripMenuItem.Image = CType(resources.GetObject("FormFungsiLeftMidRightToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FormFungsiLeftMidRightToolStripMenuItem.Name = "FormFungsiLeftMidRightToolStripMenuItem"
        Me.FormFungsiLeftMidRightToolStripMenuItem.Size = New System.Drawing.Size(337, 28)
        Me.FormFungsiLeftMidRightToolStripMenuItem.Text = "Form Fungsi Left Mid Right"
        '
        'FormInputNilaiSiswaToolStripMenuItem
        '
        Me.FormInputNilaiSiswaToolStripMenuItem.Image = CType(resources.GetObject("FormInputNilaiSiswaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FormInputNilaiSiswaToolStripMenuItem.Name = "FormInputNilaiSiswaToolStripMenuItem"
        Me.FormInputNilaiSiswaToolStripMenuItem.Size = New System.Drawing.Size(337, 28)
        Me.FormInputNilaiSiswaToolStripMenuItem.Text = "Form Input Nilai Siswa"
        '
        'FormMediaPlayerToolStripMenuItem
        '
        Me.FormMediaPlayerToolStripMenuItem.Image = CType(resources.GetObject("FormMediaPlayerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FormMediaPlayerToolStripMenuItem.Name = "FormMediaPlayerToolStripMenuItem"
        Me.FormMediaPlayerToolStripMenuItem.Size = New System.Drawing.Size(337, 28)
        Me.FormMediaPlayerToolStripMenuItem.Text = "Form Media Player"
        '
        'FormKalkulatorToolStripMenuItem
        '
        Me.FormKalkulatorToolStripMenuItem.Image = CType(resources.GetObject("FormKalkulatorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FormKalkulatorToolStripMenuItem.Name = "FormKalkulatorToolStripMenuItem"
        Me.FormKalkulatorToolStripMenuItem.Size = New System.Drawing.Size(337, 28)
        Me.FormKalkulatorToolStripMenuItem.Text = "Form Kalkulator"
        '
        'FormLuasSegitigaToolStripMenuItem
        '
        Me.FormLuasSegitigaToolStripMenuItem.Image = CType(resources.GetObject("FormLuasSegitigaToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FormLuasSegitigaToolStripMenuItem.Name = "FormLuasSegitigaToolStripMenuItem"
        Me.FormLuasSegitigaToolStripMenuItem.Size = New System.Drawing.Size(337, 28)
        Me.FormLuasSegitigaToolStripMenuItem.Text = "Form Luas Segitiga"
        '
        'FormLuasKelilingPersegipToolStripMenuItem
        '
        Me.FormLuasKelilingPersegipToolStripMenuItem.Image = CType(resources.GetObject("FormLuasKelilingPersegipToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FormLuasKelilingPersegipToolStripMenuItem.Name = "FormLuasKelilingPersegipToolStripMenuItem"
        Me.FormLuasKelilingPersegipToolStripMenuItem.Size = New System.Drawing.Size(337, 28)
        Me.FormLuasKelilingPersegipToolStripMenuItem.Text = "Form Luas & Keliling Persegi.p"
        '
        'FormLoopingToolStripMenuItem
        '
        Me.FormLoopingToolStripMenuItem.Image = CType(resources.GetObject("FormLoopingToolStripMenuItem.Image"), System.Drawing.Image)
        Me.FormLoopingToolStripMenuItem.Name = "FormLoopingToolStripMenuItem"
        Me.FormLoopingToolStripMenuItem.Size = New System.Drawing.Size(337, 28)
        Me.FormLoopingToolStripMenuItem.Text = "Form Looping"
        '
        'ChangePasswordToolStripMenuItem
        '
        Me.ChangePasswordToolStripMenuItem.Image = CType(resources.GetObject("ChangePasswordToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ChangePasswordToolStripMenuItem.Name = "ChangePasswordToolStripMenuItem"
        Me.ChangePasswordToolStripMenuItem.Size = New System.Drawing.Size(257, 28)
        Me.ChangePasswordToolStripMenuItem.Text = "Change Password"
        '
        'BackupDatabaseToolStripMenuItem
        '
        Me.BackupDatabaseToolStripMenuItem.Image = CType(resources.GetObject("BackupDatabaseToolStripMenuItem.Image"), System.Drawing.Image)
        Me.BackupDatabaseToolStripMenuItem.Name = "BackupDatabaseToolStripMenuItem"
        Me.BackupDatabaseToolStripMenuItem.Size = New System.Drawing.Size(257, 28)
        Me.BackupDatabaseToolStripMenuItem.Text = "Backup Database"
        '
        'ChangeBackgroundToolStripMenuItem
        '
        Me.ChangeBackgroundToolStripMenuItem.Image = CType(resources.GetObject("ChangeBackgroundToolStripMenuItem.Image"), System.Drawing.Image)
        Me.ChangeBackgroundToolStripMenuItem.Name = "ChangeBackgroundToolStripMenuItem"
        Me.ChangeBackgroundToolStripMenuItem.Size = New System.Drawing.Size(257, 28)
        Me.ChangeBackgroundToolStripMenuItem.Text = "Change Background"
        '
        'CloseProgramToolStripMenuItem
        '
        Me.CloseProgramToolStripMenuItem.Image = CType(resources.GetObject("CloseProgramToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CloseProgramToolStripMenuItem.Name = "CloseProgramToolStripMenuItem"
        Me.CloseProgramToolStripMenuItem.Size = New System.Drawing.Size(209, 28)
        Me.CloseProgramToolStripMenuItem.Text = "Close Program"
        '
        'Menu_Utama
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1924, 1050)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.GroupBox8)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.MaximumSize = New System.Drawing.Size(1946, 1106)
        Me.MinimumSize = New System.Drawing.Size(1918, 1006)
        Me.Name = "Menu_Utama"
        Me.Text = "Menu_Utama"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox8.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ApplicationToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormBarcodeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormQRCodeToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormFungsiLeftMidRightToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormInputNilaiSiswaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormMediaPlayerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormKalkulatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormLuasSegitigaToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormLuasKelilingPersegipToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents FormLoopingToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UtilityToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangePasswordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackupDatabaseToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ChangeBackgroundToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox8 As System.Windows.Forms.GroupBox
    Friend WithEvents Button12 As System.Windows.Forms.Button
    Friend WithEvents Button11 As System.Windows.Forms.Button
    Friend WithEvents Button10 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button13 As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents panel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents panel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents panel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CloseProgramToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
