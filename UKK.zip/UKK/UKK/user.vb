﻿Imports System.Data.Odbc
Imports System.IO
Public Class user
    Private Sub user_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Call OpenConnection()
        Call TampilGrid()
        Call tampil_status()
        TextBox1.Enabled = False
        TextBox2.Enabled = False
        ComboBox1.Enabled = False
    End Sub
    Private Sub DGV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV.CellContentClick
        On Error Resume Next
        TextBox1.Text = DGV.Rows(e.RowIndex).Cells(0).Value
        Call panggil_kode()
        If dr.HasRows Then
            Call panggil_data()
        End If
    End Sub
    Sub panggil_data()
        On Error Resume Next
        TextBox2.Text = dr.Item("password")
        ComboBox1.Text = dr.Item("status_user")
        If TextBox5.Text = dr.Item("foto") Then
        ElseIf TextBox5.Text = dr.Item("foto") Then
        End If
    End Sub
    Sub caridata()
        Call OpenConnection()
        da = New OdbcDataAdapter("select * from user where username like '%" & TextBox6.Text & "%' or jenis_kelamin like '%" & TextBox6.Text & "'", conn)
        ds = New DataSet
        da.Fill(ds)
        DGV.DataSource = ds.Tables(0)
        DGV.ReadOnly = True
    End Sub
    Sub TampilGrid()
        Call OpenConnection()
        da = New OdbcDataAdapter("select * from user", conn)
        ds = New DataSet
        da.Fill(ds)
        DGV.DataSource = ds.Tables(0)
        DGV.ReadOnly = True
    End Sub
    Sub panggil_kode()
        Call OpenConnection()
        cmd = New OdbcCommand("select * from user where username='" & TextBox1.Text & "'", conn)
        dr = cmd.ExecuteReader
        dr.Read()
    End Sub
    Sub batal()
        TextBox2.Clear()
        TextBox5.Clear()
        ComboBox1.Text = ""
        TextBox6.Clear()
        PictureBox1.Refresh()
        TextBox1.Focus()
    End Sub
    Sub tampil_status()
        Call OpenConnection()
        cmd = New OdbcCommand("select distinct status_user from user", conn)
        dr = cmd.ExecuteReader
        ComboBox1.Items.Clear()
        Do While dr.Read
            ComboBox1.Items.Add(dr.Item("status_user"))
        Loop
    End Sub
    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or ComboBox1.Text = "" Then
            MsgBox("data belum lengkap....", MsgBoxStyle.Information)
            Exit Sub
        Else
            Call panggil_kode()
            Dim newtext As String
            Dim oldtext As String = TextBox5.Text
            newtext = oldtext.Replace("\", "\\")
            If Not dr.HasRows Then
                'simpan
                Dim SIMPAN As String = "INSERT into user value('" & TextBox1.Text & "','" & TextBox2.Text & "','" & ComboBox1.Text & "','" & newtext & "')"
                cmd = New OdbcCommand(SIMPAN, conn)
                cmd.ExecuteNonQuery()
                MsgBox("data berhasil disimpan..", MsgBoxStyle.Information)
            Else
                'edit
            End If

            Call TampilGrid()
            Call batal()
            Call tampil_status()

        End If
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        If TextBox1.Text = "" Or TextBox2.Text = "" Or ComboBox1.Text = """" Then
            MsgBox("Data belum lengkap...", MsgBoxStyle.Information)
            Exit Sub
        Else
            If MessageBox.Show("Yakin akan dihapus...", "Informasi", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then
                Dim Hapus As String = "Delete from user where username='" & TextBox1.Text & "'"
                cmd = New OdbcCommand(Hapus, conn)
                cmd.ExecuteNonQuery()
                MsgBox("Data berhasil dihapus..", MsgBoxStyle.Information)
                Call TampilGrid()
                Call batal()
            End If
        End If
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        Call batal()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Me.Close()
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        MsgBox("Tambah data baru", MsgBoxStyle.Information)
        TextBox1.Enabled = True
        TextBox2.Enabled = True
        ComboBox1.Enabled = True

        Call batal()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        On Error Resume Next
        OpenFileDialog1.ShowDialog()
        OpenFileDialog1.Filter = "(*.jpg )| *.jpeg"
        PictureBox1.Text = PictureBox1.Text + "<img>" + OpenFileDialog1.FileName + "</img>"
        TextBox5.Text = OpenFileDialog1.FileName
    End Sub
End Class