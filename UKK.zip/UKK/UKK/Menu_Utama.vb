﻿Public Class Menu_Utama

    ' Property untuk menyimpan role
    Public Property userRole As String

    ' Event ketika form Menu Utama dimuat
    Private Sub Menu_Utama_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        ' Menampilkan waktu saat ini
        Label6.Text = TimeOfDay.ToString("HH:mm:ss")

        ' Cek role dan atur akses
        If userRole = "siswa" Then
            ApplicationToolStripMenuItem.Enabled = False
            GroupBox7.Enabled = False
        ElseIf userRole = "admin" Then
            ApplicationToolStripMenuItem.Enabled = True
            GroupBox7.Enabled = True
        End If
    End Sub

    ' Event untuk menutup form Menu Utama dan kembali ke Form login
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        user.Show() ' Menampilkan Form Login
        Me.Hide()        ' Menyembunyikan Form Menu Utama
    End Sub

    ' Event ketika MenuStrip1 diklik
    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked
        ' Tambahkan kode jika ada kebutuhan untuk interaksi dengan menu
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        siswa.Show()
        Me.Hide()
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        tes.Show()
        Me.Hide()
    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click
        no_pendaftaran.Show()
        Me.Hide()
    End Sub
End Class
