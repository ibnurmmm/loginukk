﻿'namespace, koneksi vb ke access
'Imports System.Data.OleDb
'===========================================BATAS=======================================================
'namespace, koneksi vb ke mysql
Imports System.Data.Odbc
Module Module1
    'Public conn As OleDbConnection
    'Public cmd As OleDbCommand
    'Public da As OleDbDataAdapter
    'Public ds As New DataSet
    'Public rd As OleDbDataReader
    'Public lokasidata As String
    'Public Sub openconnection()
    '    Dim lokasidata = "provider=Microsoft.ACE.OLEDB.12.0;Data source=DB_XIRPL5.accdb"
    '    conn = New OleDbConnection(lokasidata)
    '    If conn.State = ConnectionState.Closed Then
    '        conn.Open()
    '        MsgBox("konek Gaes...", MsgBoxStyle.Information,
    '        "informasi")
    '    End If
    'End Sub
    '===========================================BATAS===================================================
    'koneksi ke mysql
    Public conn As OdbcConnection
    Public cmd As OdbcCommand
    Public da As OdbcDataAdapter
    Public ds As New DataSet
    Public dr As OdbcDataReader
    Public rd As OdbcDataReader
    Public Sub openconnection()
        conn = New OdbcConnection("Dsn=db_sekolah")
        If conn.State = ConnectionState.Closed Then
            conn.Open()
        End If
    End Sub
End Module