﻿Public Class siswa

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Menu_Utama.Show()
        Me.Hide()
    End Sub
End Class