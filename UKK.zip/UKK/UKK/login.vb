﻿Imports System.Data.Odbc

Public Class login

    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        MENUUKK.Show()        ' Menampilkan Form Login
        Me.Hide()             ' Menyembunyikan form saat ini (opsional)
    End Sub

    Private Sub txtUsername_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtUsername.KeyPress
        txtUsername.MaxLength = 15
        If e.KeyChar = Chr(13) Then
            txtPassword.Focus()
        End If
    End Sub

    Private Sub txtPassword_KeyPress(sender As Object, e As KeyPressEventArgs) Handles txtPassword.KeyPress
        txtPassword.MaxLength = 12
        If e.KeyChar = Chr(13) Then
            btnLogin.Focus()
        End If
    End Sub

    Private Sub PictureBox2_MouseDown(sender As Object, e As MouseEventArgs) Handles PictureBox2.MouseDown
        txtPassword.UseSystemPasswordChar = False
    End Sub

    Private Sub PictureBox2_MouseUp(sender As Object, e As MouseEventArgs) Handles PictureBox2.MouseUp
        txtPassword.UseSystemPasswordChar = True
    End Sub

    Dim Peringatan As String
    Private Sub btnLogin_Click(sender As Object, e As EventArgs) Handles btnLogin.Click
        If txtUsername.Text = "" Or txtPassword.Text = "" Then
            MsgBox("Data harus diisi!", MsgBoxStyle.Critical, "PERINGATAN")
            txtUsername.Focus()
            Exit Sub
        End If

        Call openconnection()
        cmd = New OdbcCommand("SELECT * FROM users WHERE username='" & txtUsername.Text & "' AND password='" & txtPassword.Text & "'", conn)
        rd = cmd.ExecuteReader
        rd.Read()

        If rd.HasRows Then
            ' Login berhasil
            Me.Visible = False

            ' Buat form Menu Utama baru dan kirim role
            Dim menuUtama As New Menu_Utama()
            menuUtama.userRole = rd.Item("role").ToString()
            menuUtama.ToolStripStatusLabel1.Text = rd.Item("username").ToString()
            menuUtama.ToolStripStatusLabel2.Text = rd.Item("password").ToString()
            menuUtama.ToolStripStatusLabel3.Text = rd.Item("role").ToString()

            ' Tampilkan form Menu Utama
            menuUtama.Show()
        Else
            ' Login gagal
            Peringatan = Peringatan + 1
            MsgBox("Login Gagal")
            txtPassword.Focus()

            If Peringatan > 2 Then
                txtUsername.Clear()
                txtPassword.Clear()
                txtUsername.Focus()
                MsgBox("Percobaan login telah gagal lebih dari 2 kali, silakan coba lagi.", MsgBoxStyle.Critical)
                End
            End If
        End If
    End Sub
End Class
