﻿Public Class MENUUKK

    Private Sub MENUUKK_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Timer1.Start()
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Label6.Text = TimeOfDay.ToString("HH:mm:ss") ' Format 24 jam
        ' Atau pakai: Label6.Text = DateTime.Now.ToString("hh:mm:ss tt") ' Format 12 jam dengan AM/PM
    End Sub

    Private Sub Button6_Click(sender As Object, e As EventArgs) Handles Button6.Click
        login.Show()        ' Menampilkan Form Login
        Me.Hide()               ' Menyembunyikan form saat ini (opsional)
    End Sub

    Private Sub Button7_Click(sender As Object, e As EventArgs) Handles Button7.Click
        Me.Close()

    End Sub
End Class
